import React, {useEffect, useState, useMemo} from 'react'
import axios from 'axios'
import {useTable, useGlobalFilter,useFilters} from 'react-table'
import {COLUMNS} from './columns'
import './table.css'
import { GlobalFilter } from './GlobalFilter'
//import { ColumnFilter } from './ColumnFilter'

export const StudentTableFiltering =()=>{

    const [posts, setPosts]=useState([])

useEffect(() => {
   axios.get("https://api.mockaroo.com/api/a5e5dff0?count=50&key=623abeb0")
    .then(response =>
        {console.log(response.data)
            //const res =JSON.parse(response.data)
            //setPosts(res)
        setPosts(response.data)}
        )
}, [])

    const columns = useMemo(() => COLUMNS, [])
    const data = useMemo(() => posts, [posts])


    const tableInstance= useTable({
        columns,
        data,
    }, useFilters, useGlobalFilter)

    const{
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
        state,
        setGlobalFilter,
    } = tableInstance

    const {globalFilter}= state
    

    return(
        <>
        <GlobalFilter filter = {globalFilter} setFilter={setGlobalFilter}/>
        <table {...getTableProps()}>
            <thead >
                {
                    headerGroups.map((headerGroup)=>(
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {
                                headerGroup.headers.map((column)=>(
                                    <th {...column.getHeaderProps()}>{column.render('Header')}
                                     <div>
                                            {column.canFilter ? column.render('Filter'): null}
                                    </div>
                                    </th>
                                ))}
                        </tr>
                    ))
                }
            </thead>

            <tbody {...getTableBodyProps()}>
                {
                    rows.map( row=>{
                        prepareRow(row)
                        return(
                            <tr {...row.getRowProps()}>
                                {
                                    row.cells.map((cell) =>{
                                        return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                    })}
                            </tr>
                        )
                })}
            </tbody>
        </table>
        </>
    )
}