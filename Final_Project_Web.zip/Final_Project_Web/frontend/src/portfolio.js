

import emoji from "react-easy-emoji";

//

const illustration = {
  animated: true //
};

const greeting = {
  username: "Nezar Awn",
  title: "Hi all,I'm Nezar Awn",
  subTitle: emoji( "" ),
  resumeLink:
    "https://drive.google.com/", //
  displayGreeting: true //
};

// Social Media Links

const socialMediaLinks = {
  github: "https://github.com/",
  linkedin: "https://www.linkedin.com/",
  gmail: "N.awn@yahoo.com",
  gitlab: "https://gitlab.com/",
  facebook: "https://www.facebook.com/nezaroo.awn",
  medium: "https://medium.com/",
  stackoverflow: "https://stackoverflow.com/",
  //
  display: true //
};

// Skills Section

const skillsSection = {
  title: "What I do",
  subTitle: "CRAZY FULL STACK DEVELOPER WHO WANTS TO EXPLORE EVERY TECH STACK",
  skills: [
    emoji(
      "⚡ Develop highly interactive Front end / User Interfaces for your web and mobile applications"
    ),
    emoji("⚡ Progressive Web Applications ( PWA ) in normal and SPA Stacks"),
    emoji(
      "⚡ Integration of third party services such as Firebase/ AWS / Digital Ocean"
    )
  ],

  /*
https://fontawesome.com/icons?d=gallery */

  softwareSkills: [
    {
      skillName: "html-5",
      fontAwesomeClassname: "fab fa-html5"
    },
    {
      skillName: "css3",
      fontAwesomeClassname: "fab fa-css3-alt"
    },
    {
      skillName: "sass",
      fontAwesomeClassname: "fab fa-sass"
    },
    {
      skillName: "JavaScript",
      fontAwesomeClassname: "fab fa-js"
    },
    {
      skillName: "reactjs",
      fontAwesomeClassname: "fab fa-react"
    },
    {
      skillName: "nodejs",
      fontAwesomeClassname: "fab fa-node"
    },
    {
      skillName: "swift",
      fontAwesomeClassname: "fab fa-swift"
    },
    {
      skillName: "npm",
      fontAwesomeClassname: "fab fa-npm"
    },
    {
      skillName: "sql-database",
      fontAwesomeClassname: "fas fa-database"
    },
    {
      skillName: "aws",
      fontAwesomeClassname: "fab fa-aws"
    },
    {
      skillName: "firebase",
      fontAwesomeClassname: "fas fa-fire"
    },
    {
      skillName: "python",
      fontAwesomeClassname: "fab fa-python"
    },
    {
      skillName: "docker",
      fontAwesomeClassname: "fab fa-docker"
    }
  ],
  display: true //
};

// Education Section

const educationInfo = {
  display: true, //
  schools: [
    {
      schoolName: "Harvard UniversitY ",
      logo: require("./assets/images/harvardLogo.png"),
      subHeader: "Master of Science in Computer Science",
      duration: "September 2024 - April 2026",
      desc: "Articipated in the development of distance education research and published 3 research papers.",
      descBullets: [
        "Online Study",
        "Information security"
      ]
    },
    {
      schoolName: "HTW Berlin UniversitY",
      logo: require("./assets/images/htw-berlin-logo.png"),
      subHeader: "Bachelor of Science in Computer Science",
      duration: "September 2020 - April 2023",
      desc: "Ranked top 10% in the program. Took courses about Software Engineering, Web Security, Operating Systems, ...",

    }
  ]
};

//

const techStack = {
  viewSkillBars: true, //
  experience: [
    {
      Stack: "Academic", //
      progressPercentage: "90%" //
    },
    {
      Stack: "Cultural Program",
      progressPercentage: "90%"
    },
    {
      Stack: "others",
      progressPercentage: "80%"
    }
  ],
  displayCodersrank: false //
};

// Work experience section

const workExperiences = {
  display: true, //
  experience: [
    {
      role: "Software Engineer",
      company: "Facebook",
      companylogo: require("./assets/images/facebookLogo.png"),
      date: "June 2023 – Present",
      descBullets: [
      ]
    },
    {
      role: "Front-End Developer",
      company: "Quora",
      companylogo: require("./assets/images/quoraLogo.png"),
      date: "May 2024 – May 2025",
    },
    {
      role: "Software Engineer Intern",
      company: "Airbnb",
      companylogo: require("./assets/images/airbnbLogo.png"),
      date: "Jan 2027 – Sep 2028",
    }
  ]
};

/*
 */

const openSource = {
  showProfile: "true", //
  display: true //
};

// Some big projects I have worked on

const bigProjects = {
  title: "Big Projects",
  subtitle: "SOME STARTUPS AND COMPANIES THAT I HELPED TO CREATE THEIR TECH",
  projects: [
    {
      image: require("./assets/images/saayaHealthLogo.webp"),
      projectName: "",
      projectDesc: "",
      footerLink: [
        {
          name: "Visit Website",
          url: "http://.com/"
        }
        //
      ]
    },
    {
      image: require("./assets/images/nextuLogo.webp"),
      projectName: "",
      projectDesc: " ",
      footerLink: [
        {
          name: "Visit Website",
          url: "/"
        }
      ]
    }
  ],
  display: false//
};

// Achievement Section
// Include certificates, talks etc

const achievementSection = {
  title: emoji("Achievements And Certifications 🏆 "),
  subtitle:
    "Achievements, Certifications, Award Letters and Some Cool Stuff that I have done !",

  achievementsCards: [
    {
      title: "Google Code-In Finalist",
      subtitle:
        "First Yemeni to be selected as Google Code-in Finalist from 4000 students from 77 different countries.",
      image: require("./assets/images/codeInLogo.webp"),
      footerLink: [
        {
          name: "Certification",
          url: "https://drive.google.com" //
        },
        {
          name: "Award Letter",
          url: "https://drive.google.com"
        },
        {
          name: "Google Code-in Blog",
          url: "https://opensource.googleblog.com"
        }
      ]
    },
    {
      title: "Google Assistant Action",
      subtitle:
        "Developed a Google Assistant Action JavaScript Guru that is available on 2 Billion devices world wide.",
      image: require("./assets/images/googleAssistantLogo.webp"),
      footerLink: [
        {
          name: "View Google Assistant Action",
          url: "https://assistant.google.com/services/a/uid/000000100ee688ee?hl=en"
        }
      ]
    },

    {
      title: "PWA Web App Developer",
      subtitle: "Completed Certifcation from SMIT for PWA Web App Development",
      image: require("./assets/images/pwaLogo.webp"),
      footerLink: [
        {name: "Certification", url: ""},
        {
          name: "Final Project",
          url: "https://www.google.com/" /// your project link
        }
      ]
    }
  ],
  display: true //
};

// Blogs Section

const blogSection = {
  title: "Blogs",
  subtitle:
    "",
  displayMediumBlogs: "true", //
  blogs: [
    {
      url: "",
      title: "",
      description:
        ""
    },
    {
      url: "www.google.com", //
      title: "",
      description:
        "."
    }
  ],
  display: false //
};

// Talks Sections

const talkSection = {
  title: "TALKS",
  subtitle: emoji(
    "I LOVE TO SHARE MY LIMITED KNOWLEDGE AND GET A SPEAKER BADGE 😅"
  ),

  talks: [
    {
      title: "Build Actions For Google Assistant",
      subtitle: "Codelab at GDG DevFest London ",
      slides_url: "#", // your slide url here
      event_url: "https://www.facebook.com/nezaroo.awn" ///
    }
  ],
  display: true //
};

// Podcast Section

const podcastSection = {
  title: emoji("Podcast 🎙️"),
  subtitle: "I LOVE TO TALK ABOUT MYSELF AND TECHNOLOGY",

  //  The Podcast embeded Link
  podcast: [
    ""
  ],
  display: true //
};

const contactInfo = {
  title: emoji("Contact Me ☎️"),
  subtitle:
    "Discuss a project or just want to say hi? My Inbox is open for all.",
  number: "1234567890",
  email_address: "N.awn@yahoo.com"
};

// Twitter Section

const twitterDetails = {
  userName: "Google", //
  display: true //
};

export {
  illustration,
  greeting,
  socialMediaLinks,
  skillsSection,
  educationInfo,
  techStack,
  workExperiences,
  openSource,
  bigProjects,
  achievementSection,
  blogSection,
  talkSection,
  podcastSection,
  contactInfo,
  twitterDetails
};
