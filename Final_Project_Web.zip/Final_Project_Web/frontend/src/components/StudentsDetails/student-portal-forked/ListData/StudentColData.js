//import { ColumnFilter } from "./ColumnFilter";
import React, { useState, useMemo } from "react";
// import students_data from "./students_data.json";
//import  {ReactTable}  from './ReactTable';
import { Styles } from "./TableStyles";
//import { ReactTableSelect } from './ReactTableSelect';
import { ReactTableMulti } from "./ReactTableMulti";
import { ReactTableSingle } from "./ReactTableSingle";
import AddStudent from './AddStudent'
let studentsList;

export const StudentColData = () => {
  studentsList = JSON.parse(localStorage.getItem('studentslist'));
  const data = useMemo(() => studentsList, []);
  const [passCount, setPassCount] = useState(0);
  const [failCount, setFailCount] = useState(0);
  const Total = (value) => {
    let total =
      value.maths +
      value.history +
      value.english +
      value.computer +
      value.science;
    return total;
  };
  const Result = (value) => {
    const mat = value.maths;
    const tam = value.history;
    const eng = value.english;
    const com = value.computer;
    const sci = value.science;
    if (mat > 35 && tam > 35 && eng > 35 && com > 35 && sci > 35) {
      setPassCount((prevCount) => prevCount + 1);
      return <div style={{ color: "green" }}>Pass</div>;
    } else {
      setFailCount((prevCount) => prevCount + 1);
      return <div style={{ color: "red" }}>Fail</div>;
    }
  };
  const COLUMNS = [
    {
      Header: "Id",
      accessor: "id",
      disableFilters: true,
      sticky: "left"
    },
    {
      Header: "Name",
      accessor: "name",
      disableFilters: true,
      sticky: "left"
    },
    {
      Header: "English",
      disableFilters: true,
      accessor: (value) => {
        if (value.english < 35)
          return <div style={{ color: "red" }}>{value.english}</div>;
        else return <div style={{ color: "green" }}>{value.english}</div>;
      }
    },
    {
      Header: "History",
      disableFilters: true,
      accessor: (value) => {
        if (value.history < 35)
          return <div style={{ color: "red" }}>{value.history}</div>;
        else return <div style={{ color: "green" }}>{value.history}</div>;
      }
    },
    {
      Header: "Maths",
      disableFilters: true,
      accessor: (value) => {
        if (value.maths < 35)
          return <div style={{ color: "red" }}>{value.maths}</div>;
        else return <div style={{ color: "green" }}>{value.maths}</div>;
      }
    },
    {
      Header: "Computer",
      disableFilters: true,
      accessor: (value) => {
        if (value.computer < 35)
          return <div style={{ color: "red" }}>{value.computer}</div>;
        else return <div style={{ color: "green" }}>{value.computer}</div>;
      }
    },
    {
      Header: "Science",
      disableFilters: true,
      accessor: (value) => {
        if (value.science < 35)
          return <div style={{ color: "red" }}>{value.science}</div>;
        else return <div style={{ color: "green" }}>{value.science}</div>;
      }
    },
    {
      Header: "Total",
      accessor: (value) => Total(value)
    },
    {
      Header: "Average",
      accessor: (value) => Total(value) / 5
    },
    {
      Header: "Result",
      id: "result",
      accessor: (value) => Result(value)
      //Filter: ColumnFilter
      //sticky: "left"
    }
  ];

  const columns = useMemo(() => COLUMNS, []);
  // const handleSingle = () => {
  //   console.log("Single option Clicked");
  //   return (
  //     <div>
  //       <Styles>
  //         <ReactTableSingle
  //           columns={columns}
  //           data={data}
  //           passCount={passCount}
  //           failCount={failCount}
  //         />
  //       </Styles>
  //     </div>
  //   );
  // };
  // const handleMulti = () => {
  //   console.log("Multi option Clicked");
  //   return (
  //     <div>
  //       <Styles>
  //         <ReactTableMulti
  //           columns={columns}
  //           data={data}
  //           passCount={passCount}
  //           failCount={failCount}
  //         />
  //       </Styles>
  //     </div>
  //   );
  // };
  const [option, setOption] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [isDeleteModalOpen, setDeleteMoadalOpen] = useState(false);
  const DeleteModalToggle = () => {
    setDeleteMoadalOpen(!isDeleteModalOpen);
  }
  const ModalToggle = () => {
    setIsOpen(!isOpen);
  }
  //const [multi, setMulti]= useState(0)
  return (
    <div>
      <button
        className="btn-primary me-1 mb-3 p-2"
        value="Single"
        name="Single"
        onClick={() => {
         setIsOpen(!isOpen);
        }}
      >
        Add
      </button>
      {/* <br /> */}
       <button
        className="btn-danger p-2 "
        value="Multi"
        name="Multi"
        onClick={() => {
         setDeleteMoadalOpen(!isDeleteModalOpen)
        }}
      >
        Delete
      </button>
      {option === 1 ? (
        <Styles>
          <ReactTableSingle
            columns={columns}
            data={data}
            passCount={passCount}
            failCount={failCount}
          />
        </Styles>
      ) : (
        <Styles>
          <ReactTableMulti
            columns={columns}
            data={data}
            passCount={passCount}
            failCount={failCount}
          />
        </Styles>
      )}
      <AddStudent
      isOpen={isOpen}
      ModalToggle={ModalToggle}
     />
     <AddStudent
      isDeleteModalOpen={isDeleteModalOpen}
      DeleteModalToggle={DeleteModalToggle}
     />
    </div>
  );
};
