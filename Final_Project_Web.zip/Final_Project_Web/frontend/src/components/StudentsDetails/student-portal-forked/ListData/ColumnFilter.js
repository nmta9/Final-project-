import React from 'react'

export const ColumnFilter = ({column})=> {
    const {filterValue, setFilter}= column
    return(
        <span>
            {' '}
            <input 
                style={{alignItems:'center', width:'100px', height:'40px', fontSize:'25px'}}
                value={filterValue || ''}
                onChange={(e) => setFilter(e.target.value)}/>
        </span>

    )
}