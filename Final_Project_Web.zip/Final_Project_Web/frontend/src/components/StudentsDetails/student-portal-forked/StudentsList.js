import React from "react";
import  { StudentColData } from "./ListData/StudentColData";

export default function StudentsList() {
  return (
    <div>
      <StudentColData />
    </div>
  );
}
