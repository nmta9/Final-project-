import React from 'react';
import TodoList from './Components/TodoList';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Sehedule.css';

function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}

export default App;
