import React, { useMemo } from "react";
import {
  useTable,
  useGlobalFilter,
  useFilters,
  usePagination,
  useRowSelect,
  useBlockLayout
} from "react-table";
import "./table.css";
import GlobalFilter from "./GlobalFilter";
import { ColumnFilter } from "./ColumnFilter";
import { useSticky } from "react-table-sticky";

export const ReactTableMulti = ({ columns, data, passCount, failCount }) => {
  const defaultColumn = useMemo(() => {
    return {
      Filter: ColumnFilter
    };
  }, []);

  const tableInstance = useTable(
    {
      columns,
      data,
      defaultColumn
    },
    useFilters,
    useGlobalFilter,
    usePagination,
    useRowSelect,
    useBlockLayout,
    useSticky,
    //  (hooks) => {
    //       hooks.visibleColumns.push((columns) => [
    //         // Let's make a column for selection
    //         {
    //           id: "selection",
    //           // The header can use the table's getToggleAllRowsSelectedProps method to render a checkbox
    //           Header: ({ getToggleAllRowsSelectedProps }) => (
    //             <div>
    //               {/* <CheckBox {...getToggleAllRowsSelectedProps()} /> */}
    //             </div>
    //           ),
    //           // The cell can use the individual row's getToggleRowSelectedProps method to the render a checkbox
    //           Cell: ({ row }) => (
    //             <div>
    //             </div>
    //           )
    //         },
    //         ...columns
    //       ]);
    //     }
  
  );


  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    state,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    gotoPage,
    pageCount,
    setPageSize,
    setGlobalFilter,
    selectedFlatRows,
    state: { selectedRowIds }
  } = tableInstance;

  const { globalFilter, pageIndex, pageSize } = state;
  //console.log("Multiple code passed");
  return (
    <>
      <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
      <table
        {...getTableProps()}
        className="sticky"
        style={{ width: 1000, height: 500 }}
      >
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                  <div>{column.canFilter ? column.render("Filter") : null}</div>
                </th>
              ))}
            </tr>
          ))}
        </thead>
         
        <tbody {...getTableBodyProps()}>
          {page.map((row) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      <div>
        <span>
          Page{" "}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{" "}
        </span>
        <span>
          | Go to page:{" "}
          <input
            type="number"
            defaultValue={pageIndex + 1}
            onChange={(e) => {
              const pageNumber = e.target.value
                ? Number(e.target.value) - 1
                : 0;
              gotoPage(pageNumber);
            }}
            style={{ width: "100px", height:'60px', fontSize:'25px'}}
          />
        </span>
        <select
          value={pageSize}
          onChange={(e) => setPageSize(Number(e.target.value))}
        >
          {[10, 25, 50].map((pageSize) => (
            <option className="form-control" key={pageSize} value={pageSize}>
              Show {pageSize}
            </option>
          ))}
        </select>
        <button className='btn-danger m-1' onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
          {"<<"}
        </button>
        <button className='btn-success m-1' onClick={() => previousPage()} disabled={!canPreviousPage}>
          Previous
        </button>
        <button className='btn-success m-1' onClick={() => nextPage()} disabled={!canNextPage}>
          Next
        </button>
        <button className='btn-danger m-1' onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
          {">>"}
        </button>
      </div>
      {/* <br />
      <div>
        <label>Total Number of Students:{data.length}</label>
        <br />

        <label>Total No. of Pass:{passCount}</label>
        <br />
        {/* <button onClick={()=> Pass()}>View</button> */}
        {/* <label>Total No. of Fail:{failCount}</label> */}
        {/* <button onClick={()=> Fail()}>View</button>
         */}
        {/* <p>Selected Rows: {Object.keys(selectedRowIds).length}</p> */}
        {/* <pre>
          <code>
            {JSON.stringify(
              {
                selectedRowIds: selectedRowIds,
                "selectedFlatRows[].original": selectedFlatRows.map(
                  (d) => d.original
                )
              },
              null,
              2
            )}
          </code>
        </pre>
      </div> */}
    </>
  );
};
