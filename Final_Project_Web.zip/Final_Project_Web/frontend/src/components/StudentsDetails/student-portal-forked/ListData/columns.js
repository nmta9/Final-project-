import React from "react";

export const COLUMNS =[
    
    {
        Header: 'Id',
        accessor: 'id',
        disableFilters: true,
    },
    {
        Header: 'Name',
        accessor: 'name',
        disableFilters: true,
        
    },
    {
        Header: 'English',
        getRowProps: 
            (state, rowInfo) => ({
                style:{
                    backgroundColor:(rowInfo.row.english<35? 'red': null)
                }
            }),
            disableFilters: true,
            accessor: (value) => {
                if (value.english < 35)        
                    return <div style={{ color: "red" }}>{value.english}</div>;
                else 
                    return <div style={{ color: "green" }}>{value.english}</div>;    
                }
            

    },
    {
        Header: 'History',
        disableFilters: true,
        accessor: (value) => {
            if (value.history < 35)        
                return <div style={{ color: "red" }}>{value.history}</div>;
            else 
                return <div style={{ color: "green" }}>{value.history}</div>;    
            }
    },
    {
        Header: 'Maths',
        accessor:'maths',
        disableFilters: true,
    },
    {
        Header: 'Computer',
        accessor: 'computer',
        disableFilters: true,
        cell: row => {
        
        if(row.value<35)
            return (
            
              <div style={{color :'red'}}>
                {row.value}
             </div>
            
            );
        else
            return (
            
                <div style={{color :'green'}}>
                {row.value}
             </div>
              
              );
            }
    },
    {
        Header: 'Science',
        accessor: 'science',
        disableFilters: true,
    },
    {
        Header: 'Total',
        accessor: (value) => {
            const tot = value.maths+value.history+value.english+value.computer+value.science
            return (
            
              <div>
                <span>{tot}</span>
              </div>
            );
          },
        
    },
    {
        Header: 'Average',
        accessor: (value) => {
            const tot= value.maths+value.history+value.english+value.computer+value.science
            return (
            
              <div>
                <span>{tot/5}</span>
              </div>
            );
          },
    },
    {
        Header: 'Result',
        id: 'result',
        accessor: (value) => 
        {
            
            const mat= value.maths
            const tam=value.history
            const eng=value.english
            const com=value.computer
            const sci=value.science

            if(mat>35 && tam>35 && eng>35 && com>35 && sci>35)
            {
                return (
                    <div style={{color :'green'}}>
                        Pass
                    </div>
                  
                  );
            }
            else
            {
                return (
            
                    <div style={{color :'red'}}>
                    Fail
                 </div>
                  
                  );
            }
        },
    },
]