import React, {useState} from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import Typography from "@material-ui/core/Typography";
import studentList from './students_data.json'

import { TextField, Grid, Button } from "@material-ui/core";
import {
    Modal,
    ModalBody,
    ModalHeader,
    ModalFooter,
  } from "reactstrap";

const useStyles = makeStyles(theme => ({
  root: {
    marginLeft: "0%",
    width: "100%"
  },
  container: {
    maxHeight: 440
  },
  paper: {
    height: 400,
    width: 300,
    textAlign: "center",
    marginLeft: "70%",
    marginTop: "50%"
  },
  table: {},
  button: {
    margin: theme.spacing(1)
  },
  division: {
    width: 550,
    marginLeft: "30%",
    marginTop: "9%"
  },
  title: {
    fontSize: 24
  },
  theme: {
    tableLayout: "auto"
  }
}));

export default function StickyHeadTable(props) {
  const classes = useStyles();

   const AddStudent = (e) => {
       e.preventDefault();
       let tot = studentList;
       let obj = {
        id: parseInt(e.target[0].value),
        name: e.target[1].value,
        english: parseInt(e.target[2].value),
        history: parseInt(e.target[3].value),
        maths: parseInt(e.target[4].value),
        computer: parseInt(e.target[5].value),
        science: parseInt(e.target[6].value)
       }
       for (let i of studentList){
           if (i.id === obj.id){
               alert('This id already exist in this list');
               return
           }
       }
       tot.push(obj);
       console.log(tot);
       localStorage.setItem('studentslist', JSON.stringify(tot));
       props.ModalToggle();
   }
   const DeleteStudent = (e) => {
       e.preventDefault();
       let obj = JSON.parse(localStorage.getItem('studentslist'));
       let idx = -1
       for (let i  = 0; i < obj.length; ++i){
           if(obj[i].id === parseInt(e.target[0].value)){
               idx = i
           }
       }
       if(idx !== -1){
       obj.splice(idx, 1);
       console.log(idx, obj);
       localStorage.setItem('studentslist', JSON.stringify(obj));
       props.DeleteModalToggle();
       window.location.reload();
       }
       else {
           alert('This id doesn\'t exist is this list')
       }
   }
  return (
        <><div>
          <Modal isOpen={props.isOpen}>
              <ModalHeader
                  className="video__modal__header"
                  toggle={() => {
                      props.ModalToggle();
                  } }
              >
              </ModalHeader>
              <ModalBody>
                  <form onSubmit={(e) => {AddStudent(e)}}>
                      <input type="number" name="id" className='form-control p-3' placeholder='Enter id' style={{fontSize:'30px'}} required/>
                      <input type="text" name="name" className="form-control p-3" placeholder="Enter name" style={{fontSize:'30px'}} required/>
                      <input type="number" name='english' className='form-control p-3' placeholder="English number" style={{fontSize:'30px'}} required/>
                      <input type="number" name='history' className='form-control p-3' placeholder="History number" style={{fontSize:'30px'}} required/>
                      <input type="number" name='maths' className='form-control p-3' placeholder="Maths number" style={{fontSize:'30px'}} required/>
                      <input type="number" name='computer' className='form-control p-3' placeholder="Computer number" style={{fontSize:'30px'}} required/>
                      <input type="number" name='science' className='form-control p-3' placeholder="Science number" style={{fontSize:'30px'}} required/>
                      <div className="d-flex" style={{justifyContent:'space-between'}}>
                      <button onClick={() => {props.ModalToggle()}} className='btn btn-danger'>cancel</button>
                      <button type="submit" className='btn btn-primary ml-5'>submit</button>
                      </div>
                  </form>
              </ModalBody>
          </Modal>
      </div>
      <div>
          <Modal isOpen={props.isDeleteModalOpen}>
              <ModalHeader
                  className="video__modal__header"
                  toggle={() => {
                      props.DeleteModalToggle();
                  } }
              >
              </ModalHeader>
              <ModalBody>
                  <form onSubmit={(e) => {DeleteStudent(e)}}>
                      <input type="number" name="id" className='form-control p-3' placeholder='Enter id' style={{fontSize:'30px'}} required/>
                      <div className="d-flex" style={{justifyContent:'space-between'}}>
                      <button onClick={() => {props.DeleteModalToggle()}} className='btn btn-danger'>cancel</button>
                      <button type="submit" className='btn btn-primary ml-5'>submit</button>
                      </div>
                  </form>
              </ModalBody>
          </Modal>
      </div>
    </>
  );
}
