import React from 'react';
import Canvas  from './index'
export default function App() {
  return <div>
       <Canvas />
    </div>;
}
