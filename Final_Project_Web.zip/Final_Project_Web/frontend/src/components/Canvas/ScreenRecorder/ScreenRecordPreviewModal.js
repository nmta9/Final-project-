import React from 'react';
import { Modal, ModalBody, ModalHeader, Button, Row, ModalFooter } from 'reactstrap';
import { toast } from "react-toastify";
import RecordRTC from 'recordrtc';
import axios from 'axios';

var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

export default class ScreenRecordPreviewModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            spin: false,
            text: "",
        }
        this.uploadFile = this.uploadFile.bind(this);
        this.onChangeText = this.onChangeText.bind(this);
        this.UpLoadFile = this.UpLoadFile.bind(this);
    }
    onChangeText = (e) =>{
        this.setState({text: e.target.value})
    }
    // Download option for screen record
    downloadScreenRecordVideo = () => {
        let recorderBlob = this.props.recorder;
        if (!recorderBlob) {
            return;
        }
        if (isSafari) {
            if (recorderBlob && recorderBlob.getDataURL) {
                recorderBlob.getDataURL(function (dataURL) {
                    RecordRTC.SaveToDisk(dataURL, this.getFileName('mp4'));
                });
                return;
            }
        }
        if (recorderBlob) {
            var blob = recorderBlob;
            var file = new File([blob], this.getFileName('mp4'), {
                type: 'video/mp4'
            });
            RecordRTC.invokeSaveAsDialog(file);
        }
    };
    // Get file name 
    getFileName = (fileExtension) => {
        var d = new Date();
        var year = d.getFullYear();
        var month = d.getMonth();
        var date = d.getDate();
        return 'ScreenRecord-' + year + month + date + '-' + this.getRandomString() + '.' + fileExtension;
    }
    // Get random string for file name
    getRandomString = () => {
        if (window.crypto && window.crypto.getRandomValues && navigator.userAgent.indexOf('Safari') === -1) {
            var a = window.crypto.getRandomValues(new Uint32Array(3)),
                token = '';
            for (var i = 0, l = a.length; i < l; i++) {
                token += a[i].toString(36);
            }
            return token;
        } else {
            return (Math.random() * new Date().getTime()).toString(36).replace(/\./g, '');
        }
    }
    uploadFile = () =>{
        const blob = this.props.recorder;
        const formData = new FormData()
        if (this.state.text === ""){
          toast.error("Name must be required !");
        } else {
            const file = new File([blob], `${this.state.text}.mp4`);
            formData.append("file", file, this.state.text + '.mp4');
            this.UpLoadFile(formData);
        }
      }
      UpLoadFile = async (formData) => {
          console.log(formData);
        this.setState({ spin: true });
        const config = {
          headers: {
            "content-type": "multipart/form-data",
          },
        }
        const url = "http://localhost:5555/file/upload";
        await axios
          .post(url, formData, config)
          .then((res) => {
            toast.success("Uploaded Successfully");
            this.setState({ spin: false });
            this.props.videoModalClose();
          })
          .catch((err) => {
            console.log(err);
            toast.error("Uploaded fail");
            this.setState({ spin: false });
            this.props.videoModalClose();
          });
        }
    render() {
        return (
            <>
              <Modal isOpen={this.props.isOpenVideoModal}  >
                <ModalHeader className="video__modal__header" toggle={this.props.videoModalClose} >
                    < button className="lnr lnr-cross video__modal__clsBtn formModalCloseButton" type="button"
                        onClick={this.props.videoModalClose}  />
                    <span className="bold-text">Preview Screen Record</span >
                </ModalHeader >
                < ModalBody >
                    <Row className='downloadButtonAlign mb-2' >
                        <Button color='primary' outline onClick={this.downloadScreenRecordVideo} >Download</Button >
                    </Row >
                     <video id="videorecord"
                        controls
                        // controlsList="nodownload"
                        autoPlay={this.state.isLoaded}
                        playsInline
                        width={'100%'} height={'100%'}
                        src={this.props.recordedVideoUrl} />
                </ModalBody >
                <ModalFooter >
                <input type="text" className='form-control p-3' style={{fontSize:'30px'}} onChange={this.onChangeText} placeholder="Name"/>
                <Button
                    color="primary"
                    onClick={() => {
                    this.uploadFile();
                    }}
                   >
                    {this.state.spin && (
                    <span className="spinner-grow spinner-grow-sm me-1"></span>
                    )}
                    Upload{this.state.spin && "ing"}
              </Button>
                </ModalFooter>
            </Modal >
            {/* <div className="form-group">
             <ToastContainer />
            </div> */}
            </>
        )
    }
}