import React, {useState}from 'react'
import { useAsyncDebounce } from 'react-table'

const GlobalFilter = ({filter, setFilter})=> {
    const [value, setValue]= useState(filter)

    const onChange= useAsyncDebounce(value => {
        setFilter(value || undefined)
    }, 1000)
    return(
        <span style={{alignItems:'center'}}>
            search:{' '}
            <input  value={value || ''}
                    placeholder='search'
                    style={{width:'400px', height:'50px', fontSize:'27px'}}
                    onChange={(e) => 
                        {setValue(e.target.value)
                        onChange(e.target.value)}
                }/>
        </span>

    )
}
export default GlobalFilter;