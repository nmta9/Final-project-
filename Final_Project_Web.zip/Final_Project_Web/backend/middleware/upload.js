const multer = require("multer");
const GridFsStorage = require("multer-gridfs-storage");

const storage = new GridFsStorage({
    url: process.env.DB,
    options: { useNewUrlParser: true, useUnifiedTopology: true },
    file: (req, file) => {
        const match = ["image/png", "image/jpeg", "image/jpg"];

        if (match.indexOf(file.mimetype) === -1) {
            const filename = `Recording-${Date.now()}-${file.originalname}`;
            return {bucketName: "video", filename };
        }

        return {
            bucketName: "photos",
            filename: `Canvas-${Date.now()}-${file.originalname}`,
        };
    },
});

module.exports = multer({ storage });
