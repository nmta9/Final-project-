import React from "react";
import "./App.scss";
import Main from "./containers/Main";
import Canvas from "./components/Canvas/App";
import Schedule from './components/Sehedule/App'

import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import StudentsList from "./components/StudentsDetails/student-portal-forked/StudentsList";

function App() {
  return (
   <Router>
      <Routes>
         <Route exact path="/" element={<Main />} />
         <Route path='/home' element={<Main />} />
         <Route path='/canvas' element={<Canvas />} />
         <Route path='/Studentsdetails' element={ <StudentsList />} />
         <Route path='/schedule' element={ <Schedule />} />
      </Routes>
   </Router>
  );
}

export default App;
