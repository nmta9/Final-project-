import React, { useMemo } from "react";
//import axios from "axios";
import {
  useTable,
  useGlobalFilter,
  useFilters,
  usePagination
} from "react-table";
import { COLUMNS } from "./columns";
import "./table.css";
import GlobalFilter from "./GlobalFilter";
import { ColumnFilter } from "./ColumnFilter";
import students_data from './students_data.json';
//import { Pass} from "./Result";
export const StudentTable1 = () => {
//   const [posts, setPosts] = useState([]);

  const columns = useMemo(() => COLUMNS, [])
    const data = useMemo(() =>students_data, [])
    

//   useEffect(() => {
//     axios
//       .get("https://api.mockaroo.com/api/a5e5dff0?count=50&key=623abeb0")
//       .then((response) => {
//         console.log(response.data);
//         //const res =JSON.parse(response.data)
//         //setPosts(res)
//         setPosts(response.data);
//       });
//   }, []);

//   const columns = useMemo(() => COLUMNS, []);
//   const data = useMemo(() => posts, [posts]);

  const defaultColumn = useMemo(() => {
    return {
      Filter: ColumnFilter
    };
  }, []);

  const tableInstance = useTable(
    {
      columns,
      data,
      defaultColumn
    },
    useFilters,
    useGlobalFilter,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    state,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    gotoPage,
    pageCount,
    setPageSize,
    setGlobalFilter
  } = tableInstance;

  const { globalFilter, pageIndex, pageSize } = state;

  
  return (
    <>
      <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                  <div>{column.canFilter ? column.render("Filter") : null}</div>
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody {...getTableBodyProps()}>
          {page.map((row) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}                    
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      <div>
        <span>
          Page{" "}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{" "}
        </span>
        <span>
          | Go to page:{" "}
          <input
            type="number"
            defaultValue={pageIndex + 1}
            onChange={(e) => {
              const pageNumber = e.target.value
                ? Number(e.target.value) - 1
                : 0;
              gotoPage(pageNumber);
            }}
            style={{ width: "50px" }}
          />
        </span>
        <select
          value={pageSize}
          onChange={(e) => setPageSize(Number(e.target.value))}
        >
          {[5, 10, 15].map((pageSize) => (
            <option key={pageSize} value={pageSize}>
              Show {pageSize}
            </option>
          ))}
        </select>
        <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
          {"<<"}
        </button>
        <button onClick={() => previousPage()} disabled={!canPreviousPage}>
          Previous
        </button>
        <button onClick={() => nextPage()} disabled={!canNextPage}>
          Next
        </button>
        <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
          {">>"}
        </button>
      </div>
      <br />
      <div>
        <label>Total Number of Students:{data.length}</label>
        <br />
        
        <label>Total No. of Pass:</label>
        {/* <button onClick={()=> Pass()}>View</button> */}
        {/* <label>Total No. of Fail:</label>
        <button onClick={()=> Fail()}>View</button> */}
        

      </div>
    </>
  );
};
