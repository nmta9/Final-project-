// //;
import React, { useMemo, useReducer } from "react";
import students_data from "./students_data.json";
import { ReactTable } from "./ReactTable";
import { actions } from "react-table";

export const StudentColData1 = () => {
  const data = useMemo(() => students_data, []);

  const Total = (value) => {
    let total =
      value.maths +
      value.history +
      value.english +
      value.computer +
      value.science;
    return total;
  };

  const intialState = { passcount: 0, failcount: 0 };

  const counterReducer = (state = intialState, action) => {
    console.log("Count", state);
    switch (action.type) {
      case "PASS":
        return { ...state, passcount: state.passcount + 1 };
      case "FAIL":
        return { ...state, failcount: state.failcount + 1 };
      default:
        return { state };
    }
  };

  const [state, dispatch] = useReducer(counterReducer, intialState);

  const Result = (value) => {
    const mat = value.maths;
    const tam = value.history;
    const eng = value.english;
    const com = value.computer;
    const sci = value.science;
    if (mat > 35 && tam > 35 && eng > 35 && com > 35 && sci > 35) {
      dispatch({ type: "PASS" });
      return <div style={{ color: "green" }}>Pass</div>;
    } else {
      dispatch({ type: "FAIL" });
      return <div style={{ color: "red" }}>Fail</div>;
    }
  };

  const COLUMNS = [
    {
      Header: "Id",
      accessor: "id",
      //Filter: ColumnFilter
      disableFilters: true
    },
    {
      Header: "Name",
      accessor: "name",
      //Filter: ColumnFilter
      disableFilters: true
    },
    {
      Header: "English",
      //accessor: 'english',
      // getRowProps:
      //     (state, rowInfo) => ({
      //         style:{
      //             backgroundColor:(rowInfo.row.english<35? 'red': null)
      //         }
      //     }),
      //Filter: ColumnFilter
      disableFilters: true,
      accessor: (value) => {
        if (value.english < 35)
          return <div style={{ color: "red" }}>{value.english}</div>;
        else return <div style={{ color: "green" }}>{value.english}</div>;
      }
    },
    {
      Header: "History",
      //accessor: 'history',
      //Filter: ColumnFilter
      disableFilters: true,
      accessor: (value) => {
        if (value.history < 35)
          return <div style={{ color: "red" }}>{value.history}</div>;
        else return <div style={{ color: "green" }}>{value.history}</div>;
      }
    },
    {
      Header: "Maths",
      //accessor:'maths',
      //Filter: ColumnFilter
      disableFilters: true,
      accessor: (value) => {
        if (value.maths < 35)
          return <div style={{ color: "red" }}>{value.maths}</div>;
        else return <div style={{ color: "green" }}>{value.maths}</div>;
      }
    },
    {
      Header: "Computer",
      //accessor: 'computer',
      //Filter: ColumnFilter,
      disableFilters: true,
      accessor: (value) => {
        if (value.computer < 35)
          return <div style={{ color: "red" }}>{value.computer}</div>;
        else return <div style={{ color: "green" }}>{value.computer}</div>;
      }
      // cell: row => {
      //     // row.styles['color']='#fff';
      //     // row.styles['backgroundColor']=
      //     // row.value <35 ? 'red' : 'green';

      // if(row.value<35)
      //     return (

      //       <div style={{color :'red'}}>
      //         {row.value}
      //      </div>

      //     );
      //     else
      //     return (

      //         <div style={{color :'green'}}>
      //         {row.value}
      //      </div>

      //       );
      //     }
    },
    {
      Header: "Science",
      //accessor: 'science',
      //Filter: ColumnFilter
      disableFilters: true,
      accessor: (value) => {
        if (value.science < 35)
          return <div style={{ color: "red" }}>{value.science}</div>;
        else return <div style={{ color: "green" }}>{value.science}</div>;
      }
    },
    {
      Header: "Total",
      accessor: (value) => Total(value)
      //Filter: ColumnFilter
    },
    {
      Header: "Average",
      accessor: (value) => Total(value) / 5
      //Filter: ColumnFilter
    },
    {
      Header: "Result",
      id: "result",
      accessor: (value) => Result(value)
      //Filter: ColumnFilter
    }
  ];

  const columns = useMemo(() => COLUMNS, []);
  console.log("counterReducer" + JSON.stringify(state));
  return (
    <div>
      <ReactTable
        columns={columns}
        data={data}
        passCount={state.passcount}
        failCount={state.failcount}
      />
    </div>
  );
};
