export default {
    elements: [
     {}
    ],
    appState: { viewBackgroundColor: "#AFEEEE", currentItemFontFamily: 1 }
  };
  